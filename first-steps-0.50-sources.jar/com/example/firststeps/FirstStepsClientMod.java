package com.example.firststeps;

import com.example.firststeps.config.ModConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3449;
import net.minecraft.class_746;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class FirstStepsClientMod implements ClientModInitializer {
    public static final String MOD_ID = "firststeps";
    private static final int TITLE_FADE_IN = 10, TITLE_STAY = 70, TITLE_FADE_OUT = 20;
    private static final int COOLDOWN_TICKS = 40;
    private static final int MIN_MOVE_DIST_SQ = 64; // Reduced from 256 for more responsive detection
    private static final int INITIAL_CHECK_DELAY = 20;
    private static final int STRUCTURE_CHECK_RETRY = 3; // Retry detection a few times

    private static FirstStepsClientMod instance;
    private final Set<String> visitedStructures = ConcurrentHashMap.newKeySet();

    private String currentStructureId = null;
    private class_2960 currentStructureRL = null;
    private String lastStructureId = null;
    private int cooldown = 0;
    private int tickCounter = 0;
    private int initialCheckCounter = 0;
    private boolean initialCheckDone = false;
    private class_2338 lastCheckPos = null;
    private String lastWorldId = null;
    private boolean wasInGame = false;
    private int structureCheckRetryCount = 0;

    // Cache for structure ID lookups to avoid registry iteration
    private Map<class_3195, class_2960> structureIdCache = new HashMap<>();
    private boolean structureIdCacheInitialized = false;

    private static final Set<String> SMALL_STRUCTURES = Set.of(
        "buried_treasure", "ruined_portal", "ruined_portal_desert", "ruined_portal_jungle",
        "ruined_portal_mountain", "ruined_portal_nether", "ruined_portal_ocean", "ruined_portal_swamp",
        "nether_fossil", "ocean_ruin_cold", "ocean_ruin_warm", "igloo", "swamp_hut",
        "pillager_outpost", "shipwreck", "shipwreck_beached", "ocean_ruin", "ruins",
        "fossil", "desert_well", "spring", "geode", "dungeon", "mineshaft", "mineshaft_mesa",
        "stronghold", "enchanter", "hut", "shack", "shed", "well", "camp", "grave",
        "tomb", "crypt", "cage", "nest", "den", "lair", "hole", "pit",
        "ruin_small", "small_", "_small", "tiny_", "_tiny", "mini_", "_mini",
        "shrine", "altar", "obelisk", "monolith", "standing_stone", "stone_circle",
        "barrow", "cairn", "mound", "tumulus"
    );

    @Override
    public void onInitializeClient() {
        instance = this;
        ModConfig.load();
        ModConfig.setOnConfigChanged(this::onConfigChanged);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    public static FirstStepsClientMod getInstance() {
        return instance;
    }

    private void onConfigChanged() {
        lastStructureId = currentStructureId;
        currentStructureId = null;
        currentStructureRL = null;
    }

    private void onTick(class_310 mc) {
        try {
            boolean inGame = mc.field_1687 != null && mc.field_1724 != null;
            if (!inGame) {
                resetState();
                wasInGame = false;
                return;
            }

            if (!wasInGame) {
                wasInGame = true;
                initialCheckDone = false;
                initialCheckCounter = 0;
            }

            ModConfig cfg = ModConfig.getInstance();
            if (!cfg.enabled) {
                return;
            }

            if (!isEnabled(mc)) {
                return;
            }

            String worldId = getWorldId(mc);
            if (!worldId.equals(lastWorldId)) {
                visitedStructures.clear();
                resetState();
                lastWorldId = worldId;
                return;
            }

            if (cooldown > 0) {
                cooldown--;
            }

            if (!initialCheckDone) {
                if (++initialCheckCounter < INITIAL_CHECK_DELAY) {
                    return;
                }
                initialCheckDone = true;
                checkAndShowTitle(mc, cfg, true);
                return;
            }

            if (++tickCounter < cfg.getEffectiveCheckInterval()) {
                return;
            }
            tickCounter = 0;

            class_746 player = mc.field_1724;
            if (player == null) return;

            class_2338 pos = player.method_24515();
            if (lastCheckPos != null && lastCheckPos.method_10262(pos) < MIN_MOVE_DIST_SQ) {
                return;
            }
            lastCheckPos = pos;

            checkAndShowTitle(mc, cfg, false);
        } catch (Exception e) {
            // Silent fail
        }
    }

    private void checkAndShowTitle(class_310 mc, ModConfig cfg, boolean isInitialCheck) {
        try {
            class_2338 pos = mc.field_1724.method_24515();
            StructureInfo info = getStructureAtPlayer(mc, pos);
            String newStructureId = info != null ? info.id : null;

            if (!isSameStructure(newStructureId, currentStructureId)) {
                // If we detected null but had a structure before, retry a few times
                // before clearing the current structure (prevents flickering)
                if (newStructureId == null && currentStructureId != null) {
                    if (structureCheckRetryCount < STRUCTURE_CHECK_RETRY) {
                        structureCheckRetryCount++;
                        return; // Don't clear yet, retry next tick
                    }
                }
                structureCheckRetryCount = 0;

                lastStructureId = currentStructureId;
                currentStructureId = newStructureId;
                currentStructureRL = info != null ? info.location : null;

                if (currentStructureId != null && cooldown == 0) {
                    if (shouldShowTitle(currentStructureId, cfg)) {
                        showTitle(currentStructureId, currentStructureRL, mc.field_1687, cfg);
                        cooldown = COOLDOWN_TICKS;
                    }
                }
            } else if (newStructureId != null) {
                // Reset retry count when consistently detecting same structure
                structureCheckRetryCount = 0;
            }
        } catch (Exception e) {
            // Silent fail
        }
    }

    private void resetState() {
        currentStructureId = null;
        currentStructureRL = null;
        lastStructureId = null;
        cooldown = 0;
        tickCounter = 0;
        initialCheckCounter = 0;
        initialCheckDone = false;
        lastCheckPos = null;
    }

    private boolean isSameStructure(String a, String b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return a.equals(b);
    }

    private boolean shouldShowTitle(String structureId, ModConfig cfg) {
        if (cfg.firstTimeOnly) {
            if (visitedStructures.contains(structureId)) {
                return false;
            }
            visitedStructures.add(structureId);
        }
        return true;
    }

    private StructureInfo getStructureAtPlayer(class_310 mc, class_2338 pos) {
        if (mc.field_1687 == null) return null;

        try {
            var server = mc.method_1576();
            if (server == null) {
                return null;
            }

            class_3218 serverLevel = server.method_3847(mc.field_1687.method_27983());
            if (serverLevel == null) {
                return null;
            }

            var structureManager = serverLevel.method_27056();
            var structuresAtPos = structureManager.method_41037(pos);

            if (structuresAtPos == null || structuresAtPos.isEmpty()) {
                return null;
            }

            StructureInfo bestMatch = null;
            int bestPriority = Integer.MAX_VALUE;

            for (class_3195 structure : structuresAtPos.keySet()) {
                try {
                    class_3449 start = structureManager.method_28388(pos, structure);

                    if (start != null && start.method_16657()) {
                        var boundingBox = start.method_14969();
                        if (boundingBox != null && boundingBox.method_14662(pos)) {
                            class_2960 id = getStructureId(serverLevel, structure);
                            if (id != null && !isSmallStructure(id.method_12832())) {
                                int priority = getStructurePriority(id);
                                if (priority < bestPriority) {
                                    bestPriority = priority;
                                    bestMatch = new StructureInfo(id.toString(), id);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    // Skip on error
                }
            }

            return bestMatch;
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private class_2960 getStructureId(class_3218 level, class_3195 structure) {
        // Check cache first
        if (structureIdCache.containsKey(structure)) {
            return structureIdCache.get(structure);
        }

        try {
            // Initialize cache if needed
            if (!structureIdCacheInitialized) {
                var lookup = level.method_30349().method_46762(class_7924.field_41246);
                for (var entry : lookup.method_42017().toList()) {
                    var holder = (net.minecraft.class_6880.class_6883<class_3195>) entry;
                    structureIdCache.put(holder.comp_349(), holder.method_40237().method_29177());
                }
                structureIdCacheInitialized = true;
            }

            return structureIdCache.get(structure);
        } catch (Exception e) {
            return null;
        }
    }

    private boolean isSmallStructure(String path) {
        String lowerPath = path.toLowerCase();
        for (String small : SMALL_STRUCTURES) {
            if (lowerPath.contains(small)) return true;
        }
        return false;
    }

    private int getStructurePriority(class_2960 id) {
        return switch (id.method_12832()) {
            case "ancient_city" -> 1;
            case "stronghold" -> 2;
            case "monument" -> 3;
            case "mansion" -> 4;
            case "mineshaft", "mineshaft_mesa" -> 5;
            case "trial_chambers" -> 6;
            case "buried_treasure" -> 7;
            case "ruined_portal", "ruined_portal_desert", "ruined_portal_jungle",
                 "ruined_portal_mountain", "ruined_portal_nether", "ruined_portal_ocean",
                 "ruined_portal_swamp" -> 8;
            case "shipwreck", "shipwreck_beached" -> 9;
            case "ocean_ruin_cold", "ocean_ruin_warm" -> 10;
            case "igloo" -> 11;
            case "desert_pyramid" -> 12;
            case "jungle_pyramid" -> 13;
            case "swamp_hut" -> 14;
            case "pillager_outpost" -> 15;
            case "village_plains", "village_desert", "village_savanna",
                 "village_snowy", "village_taiga" -> 16;
            case "nether_fossil" -> 17;
            case "bastion_remnant" -> 18;
            case "fortress" -> 19;
            case "end_city" -> 20;
            default -> 50;
        };
    }

    private String getWorldId(class_310 mc) {
        if (mc.field_1687 == null) return "unknown";
        try {
            if (mc.method_1496()) {
                return "sp_" + mc.field_1687.method_27983().method_29177().toString();
            }
            var currentServer = mc.method_1558();
            if (currentServer != null) {
                return "mp_" + currentServer.field_3761;
            }
        } catch (Exception e) {
            // Silent fail
        }
        return "unknown";
    }

    private boolean isEnabled(class_310 mc) {
        if (!mc.method_1496()) return false;
        try {
            var server = mc.method_1576();
            if (server == null) return false;
            return server.method_3847(mc.field_1687.method_27983()) != null;
        } catch (Exception e) {
            return false;
        }
    }

    private void showTitle(String structureId, class_2960 location, class_1937 level, ModConfig cfg) {
        try {
            class_310 mc = class_310.method_1551();
            String ns = location.method_12836();
            String path = location.method_12832();

            // Check if structure has a translation - if not, don't show title
            String displayName = getStructureName(ns, path);
            if (displayName == null) {
                // No translation found for this structure, skip showing title
                return;
            }

            int titleColor = getTitleColor(ns, path, cfg);
            mc.field_1705.method_34004(class_2561.method_43470(displayName).method_27694(style -> style.method_36139(titleColor)));

            if (cfg.showSubtitle) {
                String dimName = getDimensionName(level);
                String dimKey = getDimensionKey(level);

                if (cfg.showPrefix && !"minecraft".equalsIgnoreCase(ns)) {
                    // Build subtitle with separate colors for prefix and dimension
                    int prefixColor = getColorFromLang("firststeps.prefix.color", cfg.titleColor);
                    int dimColor = getColorFromLang(dimKey + ".color", cfg.titleColor);

                    var prefixComponent = class_2561.method_43470("[" + ns + "] ").method_27694(style -> style.method_36139(prefixColor));
                    var dimComponent = class_2561.method_43470(dimName).method_27694(style -> style.method_36139(dimColor));
                    mc.field_1705.method_34002(prefixComponent.method_27661().method_10852(dimComponent));
                } else {
                    // Just dimension with its color
                    int dimColor = getColorFromLang(dimKey + ".color", cfg.titleColor);
                    mc.field_1705.method_34002(class_2561.method_43470(dimName).method_27694(style -> style.method_36139(dimColor)));
                }
            } else {
                mc.field_1705.method_34002(class_2561.method_43473());
            }

            mc.field_1705.method_34001(TITLE_FADE_IN, TITLE_STAY, TITLE_FADE_OUT);
        } catch (Exception e) {
            // Silent fail
        }
    }

    /**
     * Get title color for a structure.
     * Priority: lang file specific color > global config color > default white
     */
    private int getTitleColor(String ns, String path, ModConfig cfg) {
        // Check for language file specific color first (format: structure.<ns>.<path>.color)
        String colorKey = "structure." + ns + "." + path + ".color";
        String colorStr = net.minecraft.class_1074.method_4662(colorKey);

        if (colorStr != null && !colorStr.isEmpty() && !colorStr.equals(colorKey)) {
            try {
                // Parse hex color (support both 0xRRGGBB and #RRGGBB formats)
                if (colorStr.startsWith("#")) {
                    return Integer.parseInt(colorStr.substring(1), 16);
                } else if (colorStr.startsWith("0x") || colorStr.startsWith("0X")) {
                    return Integer.parseInt(colorStr.substring(2), 16);
                } else {
                    return Integer.parseInt(colorStr, 16);
                }
            } catch (NumberFormatException e) {
                // Invalid color format, fall through to global config
            }
        }

        // Return global config color (default white)
        return cfg.titleColor;
    }

    private String getStructureName(String ns, String path) {
        // Try exact match first
        String translationKey = "structure." + ns + "." + path;
        String translated = net.minecraft.class_1074.method_4662(translationKey);

        if (translated != null && !translated.isEmpty() && !translated.equals(translationKey)) {
            return translated;
        }

        // Try lowercase (for case-insensitive matching)
        translationKey = "structure." + ns.toLowerCase() + "." + path.toLowerCase();
        translated = net.minecraft.class_1074.method_4662(translationKey);

        if (translated != null && !translated.isEmpty() && !translated.equals(translationKey)) {
            return translated;
        }

        // No translation found - return null to indicate unknown structure
        // Users can add custom structures by adding translations to JSON lang files
        // Format: "structure.<namespace>.<path>": "Custom Structure Name"
        return null;
    }

    private String getDimensionName(class_1937 level) {
        // Use our mod's dimension translation keys
        String key;
        if (level.method_27983() == class_1937.field_25179) {
            key = "firststeps.overworld";
        } else if (level.method_27983() == class_1937.field_25180) {
            key = "firststeps.the_nether";
        } else if (level.method_27983() == class_1937.field_25181) {
            key = "firststeps.the_end";
        } else {
            key = "firststeps.unknown_dimension";
        }

        String translated = net.minecraft.class_1074.method_4662(key);
        if (translated != null && !translated.isEmpty() && !translated.equals(key)) {
            return translated;
        }

        // Fallback to English if translation not found
        if (level.method_27983() == class_1937.field_25179) return "Overworld";
        if (level.method_27983() == class_1937.field_25180) return "The Nether";
        if (level.method_27983() == class_1937.field_25181) return "The End";
        return "Unknown Dimension";
    }

    private String getDimensionKey(class_1937 level) {
        if (level.method_27983() == class_1937.field_25179) {
            return "firststeps.overworld";
        } else if (level.method_27983() == class_1937.field_25180) {
            return "firststeps.the_nether";
        } else if (level.method_27983() == class_1937.field_25181) {
            return "firststeps.the_end";
        } else {
            return "firststeps.unknown_dimension";
        }
    }

    /**
     * Get color from language file, fallback to default if not found.
     */
    private int getColorFromLang(String colorKey, int defaultColor) {
        String colorStr = net.minecraft.class_1074.method_4662(colorKey);

        if (colorStr != null && !colorStr.isEmpty() && !colorStr.equals(colorKey)) {
            try {
                if (colorStr.startsWith("#")) {
                    return Integer.parseInt(colorStr.substring(1), 16);
                } else if (colorStr.startsWith("0x") || colorStr.startsWith("0X")) {
                    return Integer.parseInt(colorStr.substring(2), 16);
                } else {
                    return Integer.parseInt(colorStr, 16);
                }
            } catch (NumberFormatException e) {
                // Invalid color format, return default
            }
        }

        return defaultColor;
    }

    private String formatStructureName(String path) {
        StringBuilder result = new StringBuilder(path.length());
        boolean capitalizeNext = true;

        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '_' || c == '-') {
                result.append(' ');
                capitalizeNext = true;
            } else if (capitalizeNext) {
                result.append(Character.toUpperCase(c));
                capitalizeNext = false;
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }

    private record StructureInfo(String id, class_2960 location) {}
}
