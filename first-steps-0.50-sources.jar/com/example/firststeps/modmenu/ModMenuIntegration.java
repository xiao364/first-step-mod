package com.example.firststeps.modmenu;

import com.example.firststeps.config.ModConfig;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;

public class ModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return ConfigScreen::new;
    }

    public static class ConfigScreen extends class_437 {
        private final class_437 parent;
        private int scrollOffset = 0;
        private static final int BUTTON_WIDTH = 200;
        private static final int BUTTON_HEIGHT = 20;
        private static final int BUTTON_SPACING = 24;
        private static final int TOP_PADDING = 40;
        private static final int BOTTOM_PADDING = 40;
        private class_342 colorInput;

        public ConfigScreen(class_437 parent) {
            super(class_2561.method_43471("firststeps.config.title"));
            this.parent = parent;
        }

        private int getContentHeight() {
            // 9 buttons * spacing + extra 12px for color label + some padding
            return BUTTON_SPACING * 9 + 12 + 20;
        }

        private int getMaxScroll() {
            int viewportHeight = this.field_22790 - TOP_PADDING - BOTTOM_PADDING;
            int contentHeight = getContentHeight();
            return Math.max(0, contentHeight - viewportHeight);
        }

        @Override
        protected void method_25426() {
            this.method_37067();
            ModConfig cfg = ModConfig.getInstance();

            int startY = TOP_PADDING - scrollOffset;
            int centerX = this.field_22789 / 2;

            // Enabled toggle
            this.method_37063(class_5676.method_32613(cfg.enabled)
                .method_32617(centerX - BUTTON_WIDTH / 2, startY, BUTTON_WIDTH, BUTTON_HEIGHT,
                    class_2561.method_43471("firststeps.config.enabled"),
                    (btn, val) -> cfg.enabled = val));

            // First time only toggle
            this.method_37063(class_5676.method_32613(cfg.firstTimeOnly)
                .method_32617(centerX - BUTTON_WIDTH / 2, startY + BUTTON_SPACING, BUTTON_WIDTH, BUTTON_HEIGHT,
                    class_2561.method_43471("firststeps.config.first_time_only"),
                    (btn, val) -> cfg.firstTimeOnly = val));

            // Show subtitle toggle
            this.method_37063(class_5676.method_32613(cfg.showSubtitle)
                .method_32617(centerX - BUTTON_WIDTH / 2, startY + BUTTON_SPACING * 2, BUTTON_WIDTH, BUTTON_HEIGHT,
                    class_2561.method_43471("firststeps.config.show_subtitle"),
                    (btn, val) -> cfg.showSubtitle = val));

            // Show prefix toggle
            this.method_37063(class_5676.method_32613(cfg.showPrefix)
                .method_32617(centerX - BUTTON_WIDTH / 2, startY + BUTTON_SPACING * 3, BUTTON_WIDTH, BUTTON_HEIGHT,
                    class_2561.method_43471("firststeps.config.show_prefix"),
                    (btn, val) -> cfg.showPrefix = val));

            // Title color label (using disabled button as label)
            class_4185 colorLabel = class_4185.method_46430(class_2561.method_43471("firststeps.config.title_color_label")
                    .method_27694(style -> style.method_36139(0xAAAAAA)), btn -> {})
                .method_46434(centerX - BUTTON_WIDTH / 2, startY + BUTTON_SPACING * 4, BUTTON_WIDTH, 12)
                .method_46431();
            colorLabel.field_22763 = false;
            this.method_37063(colorLabel);

            // Title color input
            String currentColor = String.format("%06X", cfg.titleColor);
            colorInput = new class_342(this.field_22793, centerX - BUTTON_WIDTH / 2, startY + BUTTON_SPACING * 4 + 12, BUTTON_WIDTH, BUTTON_HEIGHT,
                class_2561.method_43471("firststeps.config.title_color"));
            colorInput.method_1852(currentColor);
            colorInput.method_1880(6);
            colorInput.method_1863(value -> {
                try {
                    if (value.length() == 6) {
                        int newColor = Integer.parseInt(value, 16);
                        cfg.titleColor = newColor;
                        ModConfig.save();
                    }
                } catch (NumberFormatException e) {
                    // Invalid color, ignore
                }
            });
            this.method_37063(colorInput);

            // Detection speed toggle
            this.method_37063(class_5676.<Boolean>method_32606(val ->
                    class_2561.method_43471(val ? "firststeps.config.speed.fast" : "firststeps.config.speed.slow"))
                .method_32624(true, false)
                .method_32619(cfg.fastDetection)
                .method_32616()
                .method_32617(centerX - BUTTON_WIDTH / 2, startY + BUTTON_SPACING * 5 + 12, BUTTON_WIDTH, BUTTON_HEIGHT,
                    class_2561.method_43471("firststeps.config.detection_speed"),
                    (btn, val) -> cfg.fastDetection = val));

            // Reset button
            this.method_37063(class_4185.method_46430(class_2561.method_43471("firststeps.config.reset"), btn -> {
                ModConfig.reset();
                this.method_25426();
            }).method_46434(centerX - BUTTON_WIDTH / 2, startY + BUTTON_SPACING * 7 + 12, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

            // Done button
            this.method_37063(class_4185.method_46430(class_2561.method_43471("firststeps.config.done"), btn -> {
                saveAndClose();
            }).method_46434(centerX - BUTTON_WIDTH / 2, startY + BUTTON_SPACING * 8 + 12, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        }

        private void saveAndClose() {
            ModConfig.save();
            class_310.method_1551().method_1507(parent);
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
            super.method_25394(graphics, mouseX, mouseY, delta);

            // Note: Title is drawn by super.render() via Screen.renderBackground()
            // We avoid custom text rendering for cross-version compatibility

            // Draw scroll indicators (using simple fill rectangles instead of text)
            int maxScroll = getMaxScroll();
            if (maxScroll > 0) {
                int scrollBarX = this.field_22789 / 2 + BUTTON_WIDTH / 2 + 10;

                // Up indicator (small triangle using fill)
                if (scrollOffset > 0) {
                    graphics.method_25294(scrollBarX, TOP_PADDING, scrollBarX + 10, TOP_PADDING + 2, 0xFFAAAAAA);
                    graphics.method_25294(scrollBarX + 1, TOP_PADDING - 2, scrollBarX + 9, TOP_PADDING, 0xFFAAAAAA);
                    graphics.method_25294(scrollBarX + 2, TOP_PADDING - 4, scrollBarX + 8, TOP_PADDING - 2, 0xFFAAAAAA);
                }

                // Down indicator (small triangle using fill)
                if (scrollOffset < maxScroll) {
                    graphics.method_25294(scrollBarX, this.field_22790 - BOTTOM_PADDING - 2, scrollBarX + 10, this.field_22790 - BOTTOM_PADDING, 0xFFAAAAAA);
                    graphics.method_25294(scrollBarX + 1, this.field_22790 - BOTTOM_PADDING, scrollBarX + 9, this.field_22790 - BOTTOM_PADDING + 2, 0xFFAAAAAA);
                    graphics.method_25294(scrollBarX + 2, this.field_22790 - BOTTOM_PADDING + 2, scrollBarX + 8, this.field_22790 - BOTTOM_PADDING + 4, 0xFFAAAAAA);
                }

                // Draw scroll bar background
                int viewportHeight = this.field_22790 - TOP_PADDING - BOTTOM_PADDING;
                int contentHeight = getContentHeight();
                int scrollbarHeight = Math.max(20, (int) ((float) viewportHeight / contentHeight * viewportHeight));
                int scrollbarY = TOP_PADDING + (int) ((float) scrollOffset / maxScroll * (viewportHeight - scrollbarHeight));

                graphics.method_25294(this.field_22789 / 2 + BUTTON_WIDTH / 2 + 5, TOP_PADDING, this.field_22789 / 2 + BUTTON_WIDTH / 2 + 15, this.field_22790 - BOTTOM_PADDING, 0xFF333333);
                graphics.method_25294(this.field_22789 / 2 + BUTTON_WIDTH / 2 + 5, scrollbarY, this.field_22789 / 2 + BUTTON_WIDTH / 2 + 15, scrollbarY + scrollbarHeight, 0xFFAAAAAA);
            }
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
            int maxScroll = getMaxScroll();
            if (maxScroll > 0) {
                scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - verticalAmount * BUTTON_SPACING));
                this.method_25426();
            }
            return true;
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            if (keyCode == 256) {
                saveAndClose();
                return true;
            }
            return super.method_25404(keyCode, scanCode, modifiers);
        }

        @Override
        public void method_25419() {
            saveAndClose();
        }

        @Override
        public void method_25410(class_310 mc, int width, int height) {
            super.method_25410(mc, width, height);
            // Clamp scroll offset to valid range
            int maxScroll = getMaxScroll();
            if (scrollOffset > maxScroll) {
                scrollOffset = maxScroll;
            }
            this.method_25426();
        }
    }
}
