package com.example.firststeps.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;
import java.nio.file.*;

public class ModConfig {
    public static final String MOD_ID = "firststeps";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ModConfig instance;

    public boolean enabled = true;
    public int checkInterval = 20; // 降低检测间隔，提高响应性
    public boolean firstTimeOnly = true;
    public boolean showPrefix = false;
    public boolean showSubtitle = true;
    // Title color in RGB format (default white: 0xFFFFFF)
    public int titleColor = 0xFFFFFF;
    // Detection speed: true = fast (20 ticks), false = slow (60 ticks)
    public boolean fastDetection = true;

    // Get actual check interval based on detection speed setting
    // Fast: 20 ticks (1 second), Slow: 100 ticks (5 seconds) for better performance
    public int getEffectiveCheckInterval() {
        return fastDetection ? 20 : 100;
    }

    public static ModConfig getInstance() {
        if (instance == null) {
            load();
        }
        return instance;
    }

    public static synchronized void load() {
        if (instance != null) return;

        Path configDir = Path.of("config");
        Path configFile = configDir.resolve(MOD_ID + ".json");

        try {
            if (Files.exists(configFile)) {
                try (Reader r = Files.newBufferedReader(configFile)) {
                    ModConfig loaded = GSON.fromJson(r, ModConfig.class);
                    instance = loaded != null ? loaded : new ModConfig();
                    instance.validate();
                }
            } else {
                instance = new ModConfig();
                save();
            }
        } catch (Exception e) {
            instance = new ModConfig();
        }
    }

    private void validate() {
        if (checkInterval < 1) checkInterval = 1;
        if (checkInterval > 600) checkInterval = 600;
    }

    public static void save() {
        if (instance == null) return;

        try {
            Path configDir = Path.of("config");
            if (!Files.exists(configDir)) {
                Files.createDirectories(configDir);
            }
            try (Writer w = Files.newBufferedWriter(configDir.resolve(MOD_ID + ".json"))) {
                GSON.toJson(instance, w);
            }
        } catch (Exception e) {
            // Silent fail
        }

        notifyConfigChanged();
    }

    private static Runnable onConfigChanged = null;

    public static void setOnConfigChanged(Runnable callback) {
        onConfigChanged = callback;
    }

    private static void notifyConfigChanged() {
        if (onConfigChanged != null) {
            try {
                onConfigChanged.run();
            } catch (Exception e) {
                // Silent fail
            }
        }
    }

    public static void reset() {
        instance = new ModConfig();
        save();
        notifyConfigChanged();
    }
}
